package com.example.autenticador

class Resultado {
}